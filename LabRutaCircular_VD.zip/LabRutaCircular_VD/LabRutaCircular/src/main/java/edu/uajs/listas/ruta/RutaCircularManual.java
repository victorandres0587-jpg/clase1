package edu.uajs.listas.ruta;

import java.util.ArrayList;
import java.util.List;

public class RutaCircularManual implements RutaCircular {

    private Nodo primero;
    private Nodo actual;
    private int tamanio;

    private void enlazar(Nodo a, Nodo b) {
        a.siguiente = b;
        b.anterior = a;
    }

    @Override
    public void agregar(Parada c) {
        Nodo nuevo = new Nodo(c);
        if (primero == null) {
            enlazar(nuevo, nuevo);
            primero = nuevo;
            actual = nuevo;
        } else {
            Nodo cola = primero.anterior;
            enlazar(cola, nuevo);
            enlazar(nuevo, primero);
        }
        tamanio++;
    }

    @Override
    public Parada actual() {
        return actual != null ? actual.dato : null;
    }

    @Override
    public Parada siguiente() {
        return saltar(1);
    }

    @Override
    public Parada anterior() {
        return saltar(-1);
    }

    @Override
    public Parada saltar(int n) {
        if (tamanio == 0) return null;

        int pasos = n % tamanio;
        if (pasos > tamanio / 2) pasos -= tamanio;
        if (pasos < -(tamanio / 2)) pasos += tamanio;

        while (pasos > 0) {
            actual = actual.siguiente;
            pasos--;
        }
        while (pasos < 0) {
            actual = actual.anterior;
            pasos++;
        }
        return actual.dato;
    }

    @Override
    public Parada eliminarActual() {
        if (tamanio == 0) return null;

        if (tamanio == 1) {
            primero = null;
            actual = null;
            tamanio = 0;
            return null;
        }

        Nodo sig = actual.siguiente;
        enlazar(actual.anterior, sig);
        if (primero == actual) primero = sig;
        actual = sig;
        tamanio--;
        return sig.dato;
    }

    @Override
    public int tamanio() {
        return tamanio;
    }

    @Override
    public int tiempoTotal() {
        int suma = 0;
        Nodo aux = primero;
        for (int i = 0; i < tamanio; i++) {
            suma += aux.dato.minutos();
            aux = aux.siguiente;
        }
        return suma;
    }

    @Override
    public List<String> nombresDesdeActual() {
        List<String> lista = new ArrayList<>();
        Nodo aux = actual;
        for (int i = 0; i < tamanio; i++) {
            lista.add(aux.dato.nombre());
            aux = aux.siguiente;
        }
        return lista;
    }
}
