package edu.uajs.listas.ruta;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class RutaCircularLib implements RutaCircular {

    private final Deque<Parada> paradas = new ArrayDeque<>();

    @Override
    public void agregar(Parada c) {
        paradas.offerLast(c);
    }

    @Override
    public Parada actual() {
        return paradas.peekFirst();
    }

    @Override
    public Parada siguiente() {
        return saltar(1);
    }

    @Override
    public Parada anterior() {
        return saltar(-1);
    }

    @Override
    public Parada saltar(int n) {
        if (paradas.isEmpty()) return null;
        int giros = Math.floorMod(n, paradas.size());
        for (int i = 0; i < giros; i++) {
            paradas.offerLast(paradas.pollFirst());
        }
        return paradas.peekFirst();
    }

    @Override
    public Parada eliminarActual() {
        paradas.pollFirst();
        return paradas.peekFirst();
    }

    @Override
    public int tamanio() {
        return paradas.size();
    }

    @Override
    public int tiempoTotal() {
        return paradas.stream().mapToInt(Parada::minutos).sum();
    }

    @Override
    public List<String> nombresDesdeActual() {
        return paradas.stream().map(Parada::nombre).collect(Collectors.toList());
    }

    public boolean irA(String nombre) {
        int posicion = 0;
        for (Parada p : paradas) {
            if (p.nombre().equalsIgnoreCase(nombre)) {
                saltar(posicion);
                return true;
            }
            posicion++;
        }
        return false;
    }

    public void reordenar(long semilla) {
        List<Parada> copia = new ArrayList<>(paradas);
        Collections.shuffle(copia, new Random(semilla));
        paradas.clear();
        paradas.addAll(copia);
    }
}
