# Reflexión

**1. Avanzar sin preguntar por null**

En esta lista el último nodo apunta al primero, así que `siguiente` nunca vale null y avanzar siempre es válido. Si recorriera con `while (aux != null)` el ciclo no acabaría jamás. Por eso en mi código recorro exactamente `tamanio` nodos (o usaría un do-while contra `primero`).

**2. Olvidar actualizar `primero`**

Si borro el primer nodo y `primero` no cambia, queda apuntando a un nodo que ya no forma parte del círculo. Ejemplo: A, B, C, D y borro A; luego agrego E y se enlaza con el `anterior` de un nodo fuera de la lista, así que A reaparece y la ruta queda inconsistente. Los recorridos que parten de `primero` también fallan.

**3. Complejidad**

| Operación | Manual | Librería |
|---|---|---|
| `agregar` | O(1) | O(1) |
| `siguiente` / `anterior` | O(1) | O(1) |
| `saltar(n)` | O(tamaño/2) como máximo, porque elijo el sentido más corto | O(tamaño), porque rota paso a paso |
| `eliminarActual` | O(1) | O(1) |

**4. Circularidad lógica**

Con la librería escribo mucho menos y evito errores de enlaces, y todo el comportamiento ya está probado. A cambio no controlo los nodos: cada vez que avanzo se reordena la estructura, así que no queda un "primero" fijo ni puedo saltar de forma directa en O(1) como con referencias.

**5. Prioritaria y pendientes**

Para la parada prioritaria, una `PriorityQueue` con un comparador, porque siempre saca primero la más importante. Para las pendientes, una cola `ArrayDeque`, porque se atienden en el orden en que llegan.
